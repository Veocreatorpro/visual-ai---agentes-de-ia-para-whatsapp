const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8080;

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Visual AI Backend is Live!' });
});

app.post('/api/chat/message', async (req, res) => {
  const { message } = req.body;
  
  try {
    const response = await fetch(`${process.env.AZURE_OPENAI_ENDPOINT}/openai/deployments/${process.env.AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=${process.env.AZURE_OPENAI_API_VERSION}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': process.env.AZURE_OPENAI_KEY
      },
      body: JSON.stringify({
        messages: [
          { role: 'system', content: 'Você é um assistente de vendas da Visual AI, focado em assistência técnica de celulares e notebooks. Seja curto e direto.' },
          { role: 'user', content: message }
        ]
      })
    });

    const data = await response.json();
    res.json({ text: data.choices[0].message.content });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao processar mensagem' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
