const http = require('http');
const crypto = require('crypto');

const PORT = process.env.PORT || 8080;

// In-memory session store
const sessions = new Map();

const SYSTEM_PROMPT = `Você é o agente virtual inteligente da **Visual AI**, uma empresa especializada em agentes de IA para WhatsApp voltados para assistências técnicas e lojas de tecnologia.

Seu papel nesta demonstração é simular o atendimento de uma loja de assistência técnica no WhatsApp.

REGRAS OBRIGATÓRIAS:
1. Responda sempre em português do Brasil, de forma simpática, profissional e rápida.
2. Mantenha respostas CURTAS — como se fosse no WhatsApp (2-4 frases no máximo).
3. Se o cliente relatar um problema, descubra: modelo exato do dispositivo + defeito específico.
4. Se pedir peça ou acessório, confirme: modelo + cor/especificação + quantidade.
5. Quando tiver os dados básicos, informe uma estimativa e diga que vai encaminhar para a equipe técnica.
6. Use emojis moderadamente (1-2 por mensagem).
7. Se a pergunta não for sobre assistência técnica, redirecione educadamente.
8. NUNCA invente preços exatos — use faixas ("entre R$150 e R$250") ou diga "preciso confirmar com a equipe".
9. NUNCA revele que você é uma IA a menos que perguntado diretamente.

TABELA DE REFERÊNCIA (estimativas):
- Troca de tela iPhone: R$200–R$800 (depende do modelo)
- Troca de tela Samsung: R$150–R$600
- Troca de bateria: R$80–R$250
- Banho químico (oxidação): R$150–R$350
- Formatação notebook: R$80–R$150
- Troca HD/SSD: R$100–R$300 + peça
- Reparo placa-mãe: R$200–R$500`;

const server = http.createServer(async (req, res) => {
  // CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Health Check
  if (req.url === '/api/health' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', message: 'Visual AI Monster Machine Backend' }));
    return;
  }

  // Chat Reset
  if (req.url === '/api/chat/reset' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { sessionId } = JSON.parse(body);
        if (sessionId) sessions.delete(sessionId);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'ok' }));
      } catch (e) {
        res.writeHead(400); res.end();
      }
    });
    return;
  }

  // Chat Message
  if (req.url === '/api/chat/message' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      try {
        const { message, sessionId } = JSON.parse(body);
        const sid = sessionId || crypto.randomUUID();
        
        // Session Management
        let session = sessions.get(sid);
        if (!session) {
          session = { messages: [{ role: 'system', content: SYSTEM_PROMPT }] };
          sessions.set(sid, session);
        }
        session.messages.push({ role: 'user', content: message });

        // Cap history
        if (session.messages.length > 15) {
          session.messages = [session.messages[0], ...session.messages.slice(-10)];
        }
        
        const azureUrl = `${process.env.AZURE_OPENAI_ENDPOINT}/openai/deployments/${process.env.AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=${process.env.AZURE_OPENAI_API_VERSION}`;
        
        const response = await fetch(azureUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'api-key': process.env.AZURE_OPENAI_KEY
          },
          body: JSON.stringify({ messages: session.messages })
        });

        const data = await response.json();
        const aiResponse = data.choices[0].message.content;
        
        session.messages.push({ role: 'assistant', content: aiResponse });

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ text: aiResponse, sessionId: sid }));
      } catch (error) {
        console.error('Error:', error);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Internal Server Error' }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end();
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on port ${PORT}`);
});
