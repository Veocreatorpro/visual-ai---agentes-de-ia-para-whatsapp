const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8080;

// On Azure App Service Linux, /home is persistent and writable.
// Let's use a path that is guaranteed to be writable.
const DATA_DIR = process.env.HOME ? path.join(process.env.HOME, 'site', 'data') : path.join(__dirname, 'data');

console.log('🚀 Starting Visual AI Admin Server...');
console.log('📂 Data Directory:', DATA_DIR);

try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    console.log('✅ Created Data Directory');
  }
} catch (err) {
  console.error('❌ Failed to create Data Directory:', err);
}

const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
const STATS_PATH = path.join(DATA_DIR, 'stats.json');

// Helper to safely write JSON
const safeWrite = (file, data) => {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
    return true;
  } catch (e) {
    console.error(`❌ Error writing to ${file}:`, e);
    return false;
  }
};

// Helper to safely read JSON
const safeRead = (file, fallback) => {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    console.error(`❌ Error reading ${file}:`, e);
  }
  return fallback;
};

// Initialize files
if (!fs.existsSync(CONFIG_PATH)) safeWrite(CONFIG_PATH, { prompt: 'Você é um assistente de vendas da Visual AI. Seja curto e direto.' });
if (!fs.existsSync(STATS_PATH)) safeWrite(STATS_PATH, { clicks: 0, chats: 0 });

const server = http.createServer(async (req, res) => {
  // CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // --- PUBLIC ENDPOINTS ---

  // Health Check
  if (req.url === '/api/health' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', uptime: process.uptime() }));
    return;
  }

  // Analytics Track
  if (req.url === '/api/analytics/track' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const { type } = JSON.parse(body);
        const stats = safeRead(STATS_PATH, { clicks: 0, chats: 0 });
        if (type === 'whatsapp_click') stats.clicks++;
        if (type === 'chat_start') stats.chats++;
        safeWrite(STATS_PATH, stats);
        res.writeHead(200); res.end();
      } catch (e) { res.writeHead(400); res.end(); }
    });
    return;
  }

  // Chat Message
  if (req.url === '/api/chat/message' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      try {
        const { message } = JSON.parse(body);
        const config = safeRead(CONFIG_PATH, { prompt: 'Você é um assistente de vendas da Visual AI. Seja curto e direto.' });
        
        // Track chat start
        const stats = safeRead(STATS_PATH, { clicks: 0, chats: 0 });
        stats.chats++;
        safeWrite(STATS_PATH, stats);

        const azureUrl = `${process.env.AZURE_OPENAI_ENDPOINT}/openai/deployments/${process.env.AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=${process.env.AZURE_OPENAI_API_VERSION}`;
        
        const response = await fetch(azureUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'api-key': process.env.AZURE_OPENAI_KEY },
          body: JSON.stringify({
            messages: [
              { role: 'system', content: config.prompt },
              { role: 'user', content: message }
            ]
          })
        });

        const data = await response.json();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ text: data.choices[0].message.content }));
      } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Internal Server Error' }));
      }
    });
    return;
  }

  // --- ADMIN ENDPOINTS ---

  if (req.url === '/api/admin/stats' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(safeRead(STATS_PATH, { clicks: 0, chats: 0 })));
    return;
  }

  if (req.url === '/api/admin/config') {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(safeRead(CONFIG_PATH, { prompt: '' })));
    } else if (req.method === 'POST') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        try {
          const newConfig = JSON.parse(body);
          safeWrite(CONFIG_PATH, newConfig);
          res.writeHead(200); res.end();
        } catch (e) { res.writeHead(400); res.end(); }
      });
    }
    return;
  }

  res.writeHead(404);
  res.end();
});

server.listen(PORT, () => {
  console.log(`✅ Server listening on port ${PORT}`);
});
